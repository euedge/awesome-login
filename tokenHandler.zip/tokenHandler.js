const CryptoJS = require('crypto-js');

module.exports.createToken = function(event, context, callback) {
  let header = {
    alg: 'HS256',
    typ: 'JWT',
  };

  let secret = process.env.SECRET;
  let stringifiedHeader = CryptoJS.enc.Utf8.parse(JSON.stringify(header));
  let encodedHeader = base64url(stringifiedHeader);

  let stringifiedData = CryptoJS.enc.Utf8.parse(JSON.stringify(event));
  let encodedData = base64url(stringifiedData);

  let signature = encodedHeader + '.' + encodedData;
  signature = CryptoJS.HmacSHA256(signature, secret);
  signature = base64url(signature);

  const token = `${encodedHeader}.${encodedData}.${signature}`;
  callback(null, token);
};

function base64url(source) {
  let encodedSource = CryptoJS.enc.Base64.stringify(source);
  encodedSource = encodedSource.replace(/=+$/, '');
  encodedSource = encodedSource.replace(/\+/g, '-');
  encodedSource = encodedSource.replace(/\//g, '_');

  return encodedSource;
}
